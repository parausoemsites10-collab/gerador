# Storyboard Generator - TODO

## Fase 1: Estrutura do Projeto e Configurações
- [x] Criar estrutura base do wizard com 4 passos
- [x] Implementar navegação entre passos (anterior/próximo)
- [x] Criar tela de Configurações para armazenar chaves de API e cookies
- [x] Implementar botão de Configurações na página inicial
- [x] Adicionar rotas de validação no backend (validateGoogleApiKey, validateImageFxCookie)
- [x] Implementar validação de credenciais no CredentialsModal
- [x] Carregar credenciais salvas nas configurações automaticamente

## Fase 2: Integração com Google AI Studio (Gemini)
- [x] Integrar API do Google AI Studio (Gemini) no backend
- [x] Implementar lógica para dividir roteiro em cenas (quebra de linha = cena)
- [x] Testar processamento de roteiros
- [x] Implementar rotação automática de chaves API quando uma expira

## Fase 3: Frontend - Edição e Reordenação de Cenas
- [x] Criar interface do Passo 2 com layout de retângulos para cenas
- [x] Implementar edição de texto das cenas
- [x] Implementar exclusão de cenas
- [x] Implementar drag-and-drop para reordenação de cenas
- [x] Implementar botões anterior/próximo

## Fase 4: Frontend - Seleção de Estilo
- [x] Criar interface do Passo 3 com seleção de estilos
- [x] Implementar criação de estilos personalizados
- [x] Implementar botões anterior/próximo

## Fase 5: Backend - Geração de Prompts e Imagens
- [x] Implementar lógica de geração de prompts usando Google AI Studio
- [x] Integrar com API do ImageFX para gerar 4 imagens usando os prompts do Gemini
- [x] Implementar tempo de espera variável entre gerações (11-15 segundos)
- [x] Implementar fila de processamento de cenas
- [x] Testar integração Gemini + ImageFX

## Fase 6: Frontend - Exibição de Imagens
- [x] Criar interface do Passo 4 com exibição de 4 imagens por cena
- [x] Exibir prompt usado para cada cena
- [x] Implementar botão de download para cada imagem
- [x] Implementar layout profissional e agradável
- [x] Implementar indicador de progresso de geração
- [x] Implementar botões "Refazer Cena" e "Editar Prompt"

## Fase 7: Finalização e Entrega
- [x] Testes de funcionalidade completa
- [x] Otimizações de performance
- [x] Tratamento de erros e edge cases
- [x] Documentação do projeto

## Fase 8: Sistema de Configurações Avançadas
- [x] Adicionar botão de Configurações na página inicial
- [x] Implementar modal de configurações com validação de chaves
- [x] Adicionar suporte a múltiplas chaves API (uma por linha)
- [x] Implementar validação de chaves antes de usar
- [x] Adicionar indicadores visuais de status (válido/inválido)
- [x] Implementar rotação automática de chaves quando uma expira
- [x] Salvar configurações no localStorage
- [x] Carregar configurações automaticamente no CredentialsModal

## Correções Implementadas
- [x] **CRÍTICO:** Reorganizar wizard para Passo 0 (Credenciais obrigatórias) como primeiro passo
- [x] Tornar obrigatório inserir chave API Google e cookie ImageFX antes de qualquer ação
- [x] Melhorar prompts do Gemini para gerar descrições profissionais como um usuário faria
- [x] Integrar imageGO CLI corretamente com os prompts do Gemini
- [x] Testar fluxo completo: Credenciais → Roteiro → Cenas → Estilo → Geração de Imagens
- [x] Geração de imagens sequencial (uma cena por vez)
- [x] Delays variáveis entre gerações (11-15 segundos)
- [x] Persistência de projetos (passos 1-3)
- [x] Botões de refazer e editar prompt para cada cena
