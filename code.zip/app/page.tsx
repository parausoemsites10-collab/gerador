"use client"

import { AIChatBox } from "../client/src/components/AIChatBox"

export default function SyntheticV0PageForDeployment() {
  return <AIChatBox />
}