import { GoogleGenerativeAI } from "@google/generative-ai"

let genAI: GoogleGenerativeAI | null = null

/**
 * Inicializa o cliente do Gemini
 */
function initializeGemini() {
  const apiKey = process.env.GOOGLE_API_KEY
  if (!apiKey) {
    console.warn("[Gemini] GOOGLE_API_KEY não configurada")
    return null
  }

  if (!genAI) {
    genAI = new GoogleGenerativeAI(apiKey)
  }

  return genAI
}

/**
 * Processa um roteiro e o divide em cenas
 * @param scriptText - Texto do roteiro
 * @returns Array de cenas processadas
 */
export async function processScriptWithGemini(scriptText: string): Promise<string[]> {
  const client = initializeGemini()
  if (!client) {
    throw new Error("Gemini não está configurado. Configure GOOGLE_API_KEY.")
  }

  const model = client.getGenerativeModel({ model: "gemini-2.5-flash" })

  const prompt = `Você é um assistente especializado em roteiros e storyboards.

Analise o seguinte roteiro e divida-o em cenas claras e bem definidas. Cada cena deve ser uma descrição visual concisa que possa ser usada para gerar uma imagem.

Roteiro:
${scriptText}

Responda com APENAS uma lista de cenas, uma por linha, sem numeração ou formatação especial. Cada linha deve ser uma descrição visual completa e independente que possa ser usada como base para gerar uma imagem.`

  try {
    const response = await model.generateContent(prompt)
    const textContent = response.response.text()

    // Parse the response into scenes
    const scenes = textContent
      .split("\n")
      .map((line: string) => line.trim())
      .filter((line: string) => line.length > 0)

    return scenes
  } catch (error) {
    console.error("[Gemini] Erro ao processar roteiro:", error)
    throw error
  }
}

/**
 * Gera um prompt de imagem para uma cena usando um estilo específico
 * @param sceneDescription - Descrição da cena
 * @param style - Estilo visual desejado
 * @returns Prompt para geração de imagem
 */
export async function generateImagePromptWithGemini(sceneDescription: string, style: string): Promise<string> {
  const client = initializeGemini()
  if (!client) {
    throw new Error("Gemini não está configurado. Configure GOOGLE_API_KEY.")
  }

  const model = client.getGenerativeModel({ model: "gemini-2.5-flash" })

  const systemPrompt = `You are an expert visual prompt engineer for AI image generation. Your task is to transform scene descriptions into detailed, vivid image generation prompts.

CRITICAL INSTRUCTIONS:
- Create prompts that are DETAILED and VISUAL
- Focus on what can be SEEN: characters, objects, environment, lighting, composition
- Include specific visual details: textures, colors, materials, lighting, mood, atmosphere
- Write as if describing a photograph or film frame
- DO NOT add any art styles, artistic movements, or style references
- Only describe the SCENE CONTENT itself
- Keep prompt between 150-200 words for optimal image generation
- Use clear, specific language
- Avoid special characters, quotes, or complex punctuation`

  const userPrompt = `Transform this scene description into a detailed visual image prompt. The prompt will be used to generate images.

Scene: "${sceneDescription}"

Create a detailed visual description that includes:
1. Main subjects/characters (appearance, clothing, expression, pose)
2. Actions and interactions happening
3. The environment and setting (location, architecture, landscape)
4. Foreground, middle ground, and background elements
5. Lighting conditions (time of day, light sources, shadows, mood)
6. Colors, textures, and materials visible
7. Atmospheric effects (weather, fog, dust, particles)
8. Camera angle and composition
9. Overall mood and emotional tone

IMPORTANT: Do NOT mention any art styles, artistic movements, or style references. Only describe the visual scene content.

Write the detailed visual description (150-200 words):`

  try {
    const response = await model.generateContent({
      contents: [
        {
          role: "user",
          parts: [{ text: userPrompt }],
        },
      ],
      systemInstruction: systemPrompt,
    })

    let scenePrompt = response.response.text().trim()

    scenePrompt = scenePrompt
      .replace(/[\n\r]+/g, " ") // Replace line breaks with spaces
      .replace(/\s+/g, " ") // Replace multiple spaces with single space
      .replace(/[""]/g, '"') // Normalize smart quotes
      .replace(/['']/g, "'") // Normalize smart apostrophes
      .replace(/…/g, "...") // Normalize ellipsis
      .trim()

    if (scenePrompt.length === 0) {
      console.error(`[Gemini] ❌ ERRO: Prompt vazio gerado`)
      throw new Error("Gemini gerou um prompt vazio")
    }

    if (scenePrompt.length > 1000) {
      console.warn(`[Gemini] ⚠️ AVISO: Prompt muito longo (${scenePrompt.length} chars), truncando...`)
      scenePrompt = scenePrompt.substring(0, 1000)
    }

    // Log para debug
    console.log(`[Gemini] ========================================`)
    console.log(`[Gemini] Scene: ${sceneDescription.substring(0, 80)}...`)
    console.log(`[Gemini] Generated prompt length: ${scenePrompt.length} characters`)
    console.log(`[Gemini] Prompt preview: ${scenePrompt.substring(0, 200)}...`)
    console.log(`[Gemini] ========================================`)

    const finalPrompt = `${style.trim()} ${scenePrompt}`.trim()

    console.log(`[Gemini] ✓ Final prompt length: ${finalPrompt.length} characters`)
    console.log(`[Gemini] ✓ Final prompt: ${finalPrompt.substring(0, 250)}...`)

    return finalPrompt
  } catch (error) {
    console.error("[Gemini] ❌ Erro ao gerar prompt de imagem:", error)
    if (error instanceof Error) {
      console.error("[Gemini] Error message:", error.message)
      console.error("[Gemini] Error stack:", error.stack)
    }
    throw error
  }
}
