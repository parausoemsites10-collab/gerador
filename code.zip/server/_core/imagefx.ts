import { spawn } from "child_process"
import * as fs from "fs"
import * as path from "path"
import { fileURLToPath } from "url"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// Caminho para o binário do imageGO
const IMAGEGO_BINARY = path.join(__dirname, "../../imagego")

/**
 * Interface para os resultados da geração de imagem
 */
export interface ImageGenerationResult {
  success: boolean
  imageUrls?: string[]
  error?: string
}

/**
 * Valida se o binário imageGO existe e tem permissões de execução
 */
function validateImageGOBinary(): { valid: boolean; error?: string } {
  try {
    if (!fs.existsSync(IMAGEGO_BINARY)) {
      return {
        valid: false,
        error: `Binário imageGO não encontrado em: ${IMAGEGO_BINARY}`,
      }
    }

    // Check if file has execute permissions
    try {
      fs.accessSync(IMAGEGO_BINARY, fs.constants.X_OK)
    } catch (error) {
      return {
        valid: false,
        error: `Binário imageGO não tem permissões de execução: ${IMAGEGO_BINARY}`,
      }
    }

    return { valid: true }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Erro desconhecido"
    return {
      valid: false,
      error: `Erro ao validar binário: ${errorMessage}`,
    }
  }
}

/**
 * Sanitiza o prompt removendo caracteres problemáticos
 */
function sanitizePrompt(prompt: string): string {
  return prompt
    .replace(/[\r\n]+/g, " ") // Remove line breaks
    .replace(/\s+/g, " ") // Replace multiple spaces
    .replace(/[""]/g, '"') // Normalize quotes
    .replace(/['']/g, "'") // Normalize apostrophes
    .trim()
}

/**
 * Gera 4 imagens usando o imageGO CLI com um prompt específico
 * @param prompt - Prompt de descrição da imagem
 * @param cookie - Cookie de autenticação do Google
 * @param model - Modelo a ser usado (IMAGEN3, IMAGEN31, IMAGEN35)
 * @param size - Tamanho/proporção (SQUARE, LANDSCAPE, PORTRAIT, UNSPECIFIED)
 * @returns Resultado da geração com lista de imagens em base64
 */
export async function generateImagesWithImageFX(
  prompt: string,
  cookie: string,
  model = "IMAGEN35",
  size = "LANDSCAPE",
): Promise<ImageGenerationResult> {
  return new Promise((resolve) => {
    try {
      const binaryValidation = validateImageGOBinary()
      if (!binaryValidation.valid) {
        console.error(`[imageGO] ERRO: ${binaryValidation.error}`)
        resolve({
          success: false,
          error: binaryValidation.error,
        })
        return
      }

      if (!cookie || cookie.trim().length < 10) {
        console.error(`[imageGO] ERRO: Cookie inválido ou muito curto`)
        resolve({
          success: false,
          error: "Cookie do ImageFX inválido. Verifique se você copiou o cookie completo.",
        })
        return
      }

      const sanitizedPrompt = sanitizePrompt(prompt)
      if (sanitizedPrompt.length === 0) {
        console.error(`[imageGO] ERRO: Prompt vazio após sanitização`)
        resolve({
          success: false,
          error: "Prompt de imagem está vazio",
        })
        return
      }

      // Criar um diretório temporário para salvar as imagens
      const tempDir = `/tmp/imagefx_${Date.now()}`
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true })
      }

      console.log(`[imageGO] ========================================`)
      console.log(`[imageGO] ✓ Binário validado: ${IMAGEGO_BINARY}`)
      console.log(`[imageGO] ✓ Diretório temporário: ${tempDir}`)
      console.log(`[imageGO] ✓ Prompt (${sanitizedPrompt.length} chars): ${sanitizedPrompt.substring(0, 100)}...`)
      console.log(`[imageGO] ✓ Model: ${model}, Size: ${size}`)
      console.log(`[imageGO] ✓ Cookie length: ${cookie.length} chars`)
      console.log(`[imageGO] ========================================`)

      // Executar o imageGO com 4 imagens
      const child = spawn(IMAGEGO_BINARY, [
        "--image",
        "--prompt",
        sanitizedPrompt,
        "--cookie",
        cookie,
        "--model",
        model,
        "--size",
        size,
        "--dir",
        tempDir,
        "--count",
        "4",
        "--verbose",
      ])

      let stdout = ""
      let stderr = ""
      let timedOut = false

      const timeout = setTimeout(
        () => {
          timedOut = true
          console.error(`[imageGO] ❌ TIMEOUT: Processo levou mais de 10 minutos`)
          child.kill("SIGKILL")

          try {
            if (fs.existsSync(tempDir)) {
              fs.rmSync(tempDir, { recursive: true, force: true })
            }
          } catch (cleanupError) {
            console.warn(`[imageGO] ⚠️ Falha ao limpar diretório após timeout`)
          }

          resolve({
            success: false,
            error: "Timeout: A geração de imagens está demorando muito. Tente novamente ou verifique seu cookie.",
          })
        },
        10 * 60 * 1000,
      )

      child.stdout?.on("data", (data) => {
        const output = data.toString()
        stdout += output
        console.log(`[imageGO stdout] ${output.trim()}`)
      })

      child.stderr?.on("data", (data) => {
        const output = data.toString()
        stderr += output
        console.log(`[imageGO stderr] ${output.trim()}`)
      })

      child.on("close", (code) => {
        clearTimeout(timeout)
        if (timedOut) return

        console.log(`[imageGO] ✓ Processo finalizado com código: ${code}`)

        if (code !== 0) {
          console.error(`[imageGO] ❌ ERRO: Processo retornou código ${code}`)
          console.error(`[imageGO] stderr completo:\n${stderr}`)
          console.error(`[imageGO] stdout completo:\n${stdout}`)

          let errorMessage = `Falha ao gerar imagens (código ${code})`

          if (stderr.includes("cookie") || stderr.includes("authentication") || stderr.includes("unauthorized")) {
            errorMessage = "Cookie do ImageFX expirado ou inválido. Por favor, atualize seu cookie."
          } else if (stderr.includes("rate limit") || stderr.includes("quota")) {
            errorMessage = "Limite de requisições atingido. Aguarde alguns minutos e tente novamente."
          } else if (stderr.includes("prompt") || stderr.includes("invalid")) {
            errorMessage = "Prompt inválido. Tente reformular a descrição da cena."
          } else if (stderr.trim()) {
            errorMessage = `Erro: ${stderr.substring(0, 200)}`
          }

          resolve({
            success: false,
            error: errorMessage,
          })
          return
        }

        // Procurar pelas imagens geradas no diretório temporário
        try {
          if (!fs.existsSync(tempDir)) {
            console.error(`[imageGO] ❌ ERRO: Diretório temporário não existe: ${tempDir}`)
            resolve({
              success: false,
              error: "Diretório de imagens não foi criado",
            })
            return
          }

          const files = fs.readdirSync(tempDir)
          console.log(`[imageGO] ✓ Arquivos no diretório (${files.length}): ${files.join(", ")}`)

          const imageFiles = files.filter(
            (file) =>
              file.toLowerCase().endsWith(".jpg") ||
              file.toLowerCase().endsWith(".jpeg") ||
              file.toLowerCase().endsWith(".png"),
          )

          console.log(`[imageGO] ✓ Imagens encontradas: ${imageFiles.length}`)

          if (imageFiles.length === 0) {
            console.error(`[imageGO] ❌ ERRO: Nenhuma imagem encontrada em ${tempDir}`)
            console.error(`[imageGO] stdout:\n${stdout}`)
            console.error(`[imageGO] stderr:\n${stderr}`)
            resolve({
              success: false,
              error: "Nenhuma imagem foi gerada. Verifique seu cookie e tente novamente.",
            })
            return
          }

          // Ler as imagens e converter para base64
          const imageUrls: string[] = []
          for (const imageFile of imageFiles) {
            const imagePath = path.join(tempDir, imageFile)
            const imageBuffer = fs.readFileSync(imagePath)
            const imageBase64 = imageBuffer.toString("base64")

            const mimeType = imageFile.toLowerCase().endsWith(".png") ? "image/png" : "image/jpeg"

            imageUrls.push(`data:${mimeType};base64,${imageBase64}`)
            console.log(`[imageGO] ✓ Imagem lida: ${imageFile} (${(imageBuffer.length / 1024).toFixed(2)} KB)`)
          }

          // Limpar o diretório temporário
          try {
            fs.rmSync(tempDir, { recursive: true, force: true })
            console.log(`[imageGO] ✓ Diretório temporário limpo`)
          } catch (cleanupError) {
            console.warn(`[imageGO] ⚠️ AVISO: Falha ao limpar diretório: ${cleanupError}`)
          }

          console.log(`[imageGO] ✅ SUCESSO: ${imageUrls.length} imagens geradas`)
          console.log(`[imageGO] ========================================\n`)

          resolve({
            success: true,
            imageUrls,
          })
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Erro desconhecido"
          console.error(`[imageGO] ❌ ERRO ao processar imagens: ${errorMessage}`)
          console.error(`[imageGO] Stack trace:`, error)
          resolve({
            success: false,
            error: `Erro ao processar imagens: ${errorMessage}`,
          })
        }
      })

      child.on("error", (error) => {
        clearTimeout(timeout)
        console.error(`[imageGO] ❌ ERRO ao iniciar processo: ${error.message}`)
        console.error(`[imageGO] Stack trace:`, error)

        try {
          if (fs.existsSync(tempDir)) {
            fs.rmSync(tempDir, { recursive: true, force: true })
          }
        } catch (cleanupError) {
          console.warn(`[imageGO] ⚠️ Falha ao limpar diretório após erro`)
        }

        resolve({
          success: false,
          error: `Erro ao iniciar imageGO: ${error.message}. Verifique se o binário tem permissões de execução.`,
        })
      })
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Erro desconhecido"
      console.error(`[imageGO] ❌ ERRO geral: ${errorMessage}`)
      console.error(`[imageGO] Stack trace:`, error)
      resolve({
        success: false,
        error: `Erro ao gerar imagens: ${errorMessage}`,
      })
    }
  })
}

/**
 * Gera imagens para múltiplas cenas com delays variáveis
 * @param scenes - Array de cenas com prompts
 * @param cookie - Cookie de autenticação do Google
 * @param onProgress - Callback para relatar progresso
 * @returns Array de resultados de geração
 */
export async function generateImagesForScenesWithDelay(
  scenes: Array<{ sceneId: string; prompt: string }>,
  cookie: string,
  onProgress?: (progress: { currentScene: number; totalScenes: number; sceneId: string }) => void,
): Promise<Array<{ sceneId: string; images: string[]; error?: string }>> {
  console.log(`[imageGO] ========================================`)
  console.log(`[imageGO] 🚀 INICIANDO GERAÇÃO DE ${scenes.length} CENAS`)
  console.log(`[imageGO] ========================================`)

  const binaryValidation = validateImageGOBinary()
  if (!binaryValidation.valid) {
    console.error(`[imageGO] ❌ ${binaryValidation.error}`)
    return scenes.map((scene) => ({
      sceneId: scene.sceneId,
      images: [],
      error: binaryValidation.error,
    }))
  }

  const results: Array<{ sceneId: string; images: string[]; error?: string }> = []

  for (let i = 0; i < scenes.length; i++) {
    const scene = scenes[i]
    console.log(`[imageGO] \n📸 [CENA ${i + 1}/${scenes.length}] Processando: ${scene.sceneId}`)
    console.log(`[imageGO] Prompt: ${scene.prompt.substring(0, 150)}...`)

    // Relatar progresso
    if (onProgress) {
      onProgress({
        currentScene: i + 1,
        totalScenes: scenes.length,
        sceneId: scene.sceneId,
      })
    }

    // Gerar imagens para a cena
    console.log(`[imageGO] → Chamando generateImagesWithImageFX...`)
    const result = await generateImagesWithImageFX(scene.prompt, cookie, "IMAGEN35", "LANDSCAPE")

    if (result.success && result.imageUrls) {
      results.push({
        sceneId: scene.sceneId,
        images: result.imageUrls,
      })
      console.log(`[imageGO] ✅ SUCESSO: ${result.imageUrls.length} imagens para cena ${scene.sceneId}`)
    } else {
      results.push({
        sceneId: scene.sceneId,
        images: [],
        error: result.error,
      })
      console.error(`[imageGO] ❌ ERRO na cena ${scene.sceneId}: ${result.error}`)
    }

    if (i < scenes.length - 1) {
      const delayMs = 15000 + Math.random() * 5000 // 15-20 segundos
      console.log(`[imageGO] ⏳ Aguardando ${(delayMs / 1000).toFixed(1)}s antes da próxima cena...`)
      await new Promise((resolve) => setTimeout(resolve, delayMs))
    }
  }

  console.log(`[imageGO] \n========================================`)
  console.log(`[imageGO] 🏁 GERAÇÃO CONCLUÍDA`)
  console.log(`[imageGO] Total de cenas: ${scenes.length}`)
  console.log(`[imageGO] ✅ Sucesso: ${results.filter((r) => r.images.length > 0).length}`)
  console.log(`[imageGO] ❌ Erros: ${results.filter((r) => r.error).length}`)
  console.log(`[imageGO] ========================================\n`)

  return results
}
