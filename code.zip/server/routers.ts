import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { processScriptWithGemini, generateImagePromptWithGemini } from "./_core/gemini";
import { generateImagesForScenesWithDelay } from "./_core/imagefx";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  storyboard: router({
    processScript: publicProcedure
      .input(
        z.object({
          scriptText: z.string().min(1, "Roteiro é obrigatório"),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const scenes = await processScriptWithGemini(input.scriptText);
          return {
            success: true,
            scenes,
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Erro desconhecido";
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: `Erro ao processar roteiro: ${errorMessage}`,
          });
        }
      }),

    generateImagePrompt: publicProcedure
      .input(
        z.object({
          sceneDescription: z.string().min(1, "Descrição da cena é obrigatória"),
          style: z.string().min(1, "Estilo é obrigatório"),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const prompt = await generateImagePromptWithGemini(
            input.sceneDescription,
            input.style
          );
          return {
            success: true,
            prompt,
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Erro desconhecido";
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: `Erro ao gerar prompt: ${errorMessage}`,
          });
        }
      }),

    validateGoogleApiKey: publicProcedure
      .input(
        z.object({
          apiKeys: z.array(z.string()).min(1, "Pelo menos uma chave é obrigatória"),
        })
      )
      .mutation(async ({ input }) => {
        try {
          for (const apiKey of input.apiKeys) {
            try {
              process.env.GOOGLE_API_KEY = apiKey;
              const result = await processScriptWithGemini("Test");
              if (result && result.length > 0) {
                return { valid: true };
              }
            } catch (error) {
              console.log(`Chave inválida: ${apiKey}`);
              continue;
            }
          }
          return { valid: false };
        } catch (error) {
          return { valid: false };
        }
      }),

    validateImageFxCookie: publicProcedure
      .input(
        z.object({
          cookie: z.string().min(1, "Cookie é obrigatório"),
        })
      )
      .mutation(async ({ input }) => {
        try {
          return { valid: true };
        } catch (error) {
          return { valid: false };
        }
      }),

    generateStoryboardImages: publicProcedure
      .input(
        z.object({
          scenes: z.array(
            z.object({
              sceneId: z.string(),
              sceneDescription: z.string(),
            })
          ),
          style: z.string().min(1, "Estilo é obrigatório"),
          imageFxCookie: z.string().min(1, "Cookie do ImageFX é obrigatório"),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const scenesWithPrompts = await Promise.all(
            input.scenes.map(async (scene) => {
              try {
                const prompt = await generateImagePromptWithGemini(
                  scene.sceneDescription,
                  input.style
                );
                return {
                  sceneId: scene.sceneId,
                  prompt,
                };
              } catch (error) {
                console.error(`Erro ao gerar prompt para cena ${scene.sceneId}:`, error);
                return {
                  sceneId: scene.sceneId,
                  prompt: `${input.style} ${scene.sceneDescription}`,
                };
              }
            })
          );

          const results = await generateImagesForScenesWithDelay(
            scenesWithPrompts,
            input.imageFxCookie
          );

          const resultsWithPrompts = results.map((result) => {
            const sceneWithPrompt = scenesWithPrompts.find((s) => s.sceneId === result.sceneId);
            return {
              ...result,
              prompt: sceneWithPrompt?.prompt,
            };
          });

          return {
            success: true,
            results: resultsWithPrompts,
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Erro desconhecido";
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: `Erro ao gerar storyboard: ${errorMessage}`,
          });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
