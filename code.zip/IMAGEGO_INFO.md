# ImageGO CLI - Informações de Integração

## Uso Básico

\`\`\`bash
./imagego --image --prompt "purple cat" --cookie "$GOOGLE_COOKIE"
\`\`\`

## Flags Disponíveis

\`\`\`
imagego [flags] --cookie [cookie]

  -caption
        Generate description from an image
  -cookie string
        User account cookie (OBRIGATÓRIO)
  -count int
        Number of images to generate (default 1)
  -dir string
        Destination directory to save images (default ".")
  -fetch
        Fetch generated images using unique media ID
  -id string
        Unique media generation id
  -image
        Generate image from a prompt
  -model string
        Model to use for generation (default "IMAGEN35")
  -prompt string
        Textual description for the image (default "Purple cat")
  -seed int
        A specific number that serves as the starting point
  -size string
        Aspect ratio of the image (default "LANDSCAPE")
  -verbose
        Extra logs
\`\`\`

## Valores Disponíveis

**Sizes:** SQUARE, LANDSCAPE, PORTRAIT, UNSPECIFIED
**Models:** IMAGEN3, IMAGEN31, IMAGEN35

## Exemplo Completo

\`\`\`bash
./imagego --image \
  --prompt "A serene landscape with mountains and a sunset, oil painting style" \
  --cookie "your_google_cookie_here" \
  --count 4 \
  --model IMAGEN35 \
  --size LANDSCAPE \
  --dir ./output
\`\`\`

## Como Obter o Cookie

### Método Fácil
1. Instalar extensão Cookie Editor no navegador
2. Abrir https://labs.google.com
3. Clicar no ícone da extensão
4. Clicar em Export → Header String

### Método Manual
1. Abrir https://labs.google.com (estar logado)
2. Pressionar CTRL + SHIFT + I (abrir console)
3. Clicar na aba "Network"
4. Pressionar CTRL + L (limpar logs)
5. Pressionar CTRL + R (recarregar)
6. Clicar em "image-fx" (deve estar no topo)
7. Ir para "Request Headers" e copiar o valor de "Cookie"

## Integração com Gemini

O Gemini deve gerar prompts no formato que o imageGO espera:
- Descrições visuais detalhadas
- Incluir estilo, iluminação, composição
- Em inglês
- Sem instruções técnicas (apenas descrição visual)

Exemplo de prompt gerado pelo Gemini:
\`\`\`
"A majestic dragon perched on a mountain peak, scales shimmering with iridescent colors, 
dramatic lighting with storm clouds in the background, cinematic composition, 
oil painting style with rich textures and depth"
\`\`\`
