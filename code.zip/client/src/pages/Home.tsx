import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Plus, Trash2, Play, Settings } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import CredentialsModal from "@/components/CredentialsModal";
import SettingsModal from "@/components/SettingsModal";

interface Project {
  id: string;
  name: string;
  scriptText: string;
  scenes: Array<{ id: string; text: string }>;
  selectedStyle: string;
  imageAspectRatio: string;
  customStyle?: string;
  createdAt: string;
  updatedAt: string;
}

export default function Home() {
  const [, setLocation] = useLocation();
  const [projects, setProjects] = useState<Project[]>([]);
  const [showCredentialsModal, setShowCredentialsModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("storyboard_projects");
    if (stored) {
      try {
        setProjects(JSON.parse(stored));
      } catch (error) {
        console.error("Erro ao carregar projetos:", error);
      }
    }
  }, []);

  const handleDeleteProject = (projectId: string) => {
    if (confirm("Tem certeza que deseja deletar este projeto?")) {
      const updated = projects.filter((p) => p.id !== projectId);
      setProjects(updated);
      localStorage.setItem("storyboard_projects", JSON.stringify(updated));
      toast.success("Projeto deletado com sucesso!");
    }
  };

  const handleOpenProject = (project: Project) => {
    localStorage.setItem("storyboard_wizard_state", JSON.stringify({
      currentStep: 1,
      scriptText: project.scriptText,
      scenes: project.scenes,
      selectedStyle: project.selectedStyle,
      imageAspectRatio: project.imageAspectRatio,
      customStyle: project.customStyle,
    }));
    setLocation("/wizard");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <div className="border-b border-slate-800 sticky top-0 z-50 bg-slate-950/95 backdrop-blur">
        <div className="max-w-7xl mx-auto px-6 py-6 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Storyboard AI</h1>
            <p className="text-slate-400 text-sm mt-1">Transforme roteiros em storyboards visuais com IA</p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => setShowSettingsModal(true)}
              variant="outline"
              size="lg"
              className="gap-2 border-slate-700 text-slate-300 hover:bg-slate-800"
            >
              <Settings className="w-5 h-5" />
              Configurações
            </Button>
            <Button
              onClick={() => setShowCredentialsModal(true)}
              className="gap-2 bg-indigo-600 hover:bg-indigo-700 text-white"
              size="lg"
            >
              <Plus className="w-5 h-5" />
              Novo Projeto
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-12">
        {projects.length === 0 ? (
          <div className="text-center py-20">
            <div className="mb-6">
              <div className="w-20 h-20 rounded-full bg-indigo-600/20 flex items-center justify-center mx-auto mb-4">
                <Play className="w-10 h-10 text-indigo-400" />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Nenhum projeto criado ainda</h2>
            <p className="text-slate-400 mb-8">Comece criando seu primeiro storyboard com IA</p>
            <Button
              onClick={() => setShowCredentialsModal(true)}
              className="gap-2 bg-indigo-600 hover:bg-indigo-700 text-white"
              size="lg"
            >
              <Plus className="w-5 h-5" />
              Criar Primeiro Projeto
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project) => (
              <Card
                key={project.id}
                className="bg-slate-800 border-slate-700 hover:border-indigo-500 transition-colors overflow-hidden group cursor-pointer"
              >
                <div className="p-6 flex flex-col h-full">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-white mb-2 truncate">
                      {project.name}
                    </h3>
                    <p className="text-slate-400 text-sm mb-4 line-clamp-3">
                      {project.scriptText}
                    </p>
                    <div className="flex gap-2 text-xs text-slate-500">
                      <span>{project.scenes.length} cenas</span>
                      <span>•</span>
                      <span>{project.selectedStyle || "Sem estilo"}</span>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-slate-700 flex gap-2">
                    <Button
                      onClick={() => handleOpenProject(project)}
                      variant="outline"
                      size="sm"
                      className="flex-1 border-slate-600 text-indigo-400 hover:bg-indigo-600/10"
                    >
                      <Play className="w-4 h-4 mr-1" />
                      Abrir
                    </Button>
                    <Button
                      onClick={() => handleDeleteProject(project.id)}
                      variant="outline"
                      size="sm"
                      className="border-slate-600 text-red-400 hover:bg-red-600/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <p className="text-xs text-slate-500 mt-3">
                    {new Date(project.updatedAt).toLocaleDateString("pt-BR")}
                  </p>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Credentials Modal */}
      {showCredentialsModal && (
        <CredentialsModal
          onClose={() => setShowCredentialsModal(false)}
          onConfirm={() => {
            setShowCredentialsModal(false);
            setLocation("/wizard");
          }}
        />
      )}

      {/* Settings Modal */}
      {showSettingsModal && (
        <SettingsModal
          onClose={() => setShowSettingsModal(false)}
        />
      )}
    </div>
  );
}
