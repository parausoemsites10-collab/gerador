import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Save } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function Settings() {
  const [, setLocation] = useLocation();
  const [googleApiKey, setGoogleApiKey] = useState("");
  const [imageFxCookie, setImageFxCookie] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  // Load settings from localStorage on mount
  useEffect(() => {
    const savedGoogleKey = localStorage.getItem("googleApiKey") || "";
    const savedImageFxCookie = localStorage.getItem("imageFxCookie") || "";
    setGoogleApiKey(savedGoogleKey);
    setImageFxCookie(savedImageFxCookie);
  }, []);

  const handleSave = async () => {
    if (!googleApiKey.trim() || !imageFxCookie.trim()) {
      toast.error("Por favor, preencha todos os campos");
      return;
    }

    setIsSaving(true);
    try {
      // Save to localStorage for now
      localStorage.setItem("googleApiKey", googleApiKey);
      localStorage.setItem("imageFxCookie", imageFxCookie);
      toast.success("Configurações salvas com sucesso!");
    } catch (error) {
      toast.error("Erro ao salvar configurações");
      console.error(error);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/")}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Configurações</h1>
            <p className="text-gray-600 mt-1">Gerencie suas chaves de API e credenciais</p>
          </div>
        </div>

        {/* Google AI Studio Settings */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Google AI Studio (Gemini)</CardTitle>
            <CardDescription>
              Chave de API para acessar o Google AI Studio e processar roteiros
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="googleApiKey">Chave de API do Google AI Studio</Label>
              <Input
                id="googleApiKey"
                type="password"
                placeholder="Insira sua chave de API"
                value={googleApiKey}
                onChange={(e) => setGoogleApiKey(e.target.value)}
                className="mt-2"
              />
              <p className="text-xs text-gray-500 mt-2">
                Obtenha sua chave em{" "}
                <a
                  href="https://ai.google.dev"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline"
                >
                  ai.google.dev
                </a>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* ImageFX Settings */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>ImageFX</CardTitle>
            <CardDescription>
              Cookie de autenticação para acessar a API do ImageFX
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="imageFxCookie">Cookie do ImageFX</Label>
              <Textarea
                id="imageFxCookie"
                placeholder="Cole aqui o cookie completo do Google obtido em labs.google/fx"
                value={imageFxCookie}
                onChange={(e) => setImageFxCookie(e.target.value)}
                className="mt-2 font-mono text-xs"
                rows={5}
              />
              <p className="text-xs text-gray-500 mt-2">
                Como obter o cookie: Abra{" "}
                <a
                  href="https://labs.google.com/fx"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline"
                >
                  labs.google.com/fx
                </a>
                , pressione F12, vá para Network, recarregue a página, clique em "image-fx", copie o
                valor do campo Cookie nos Request Headers.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Save Button */}
        <div className="flex gap-4">
          <Button
            variant="outline"
            onClick={() => setLocation("/")}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleSave}
            disabled={isSaving}
            className="gap-2 bg-indigo-600 hover:bg-indigo-700"
          >
            <Save className="w-4 h-4" />
            {isSaving ? "Salvando..." : "Salvar Configurações"}
          </Button>
        </div>
      </div>
    </div>
  );
}
