import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Plus, Trash2, Eye, Calendar, FileText } from "lucide-react";
import { toast } from "sonner";

interface StoredProject {
  id: string;
  name: string;
  scriptText: string;
  scenes: Array<{ id: string; text: string }>;
  selectedStyle: string;
  imageAspectRatio: string;
  customStyle?: string;
  generatedImages?: Array<{
    sceneId: string;
    images: string[];
    prompt?: string;
  }>;
  createdAt: string;
  updatedAt: string;
}

export default function Projects() {
  const [, setLocation] = useLocation();
  const [projects, setProjects] = useState<StoredProject[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = () => {
    try {
      const stored = localStorage.getItem("storyboard_projects");
      if (stored) {
        const projectList = JSON.parse(stored);
        setProjects(projectList);
      }
    } catch (error) {
      console.error("Erro ao carregar projetos:", error);
      toast.error("Erro ao carregar projetos");
    } finally {
      setLoading(false);
    }
  };

  const deleteProject = (projectId: string) => {
    if (confirm("Tem certeza que deseja deletar este projeto?")) {
      try {
        const updated = projects.filter((p) => p.id !== projectId);
        setProjects(updated);
        localStorage.setItem("storyboard_projects", JSON.stringify(updated));
        toast.success("Projeto deletado com sucesso");
      } catch (error) {
        toast.error("Erro ao deletar projeto");
      }
    }
  };

  const openProject = (project: StoredProject) => {
    // Salvar o projeto no estado do wizard
    localStorage.setItem(
      "storyboard_wizard_state",
      JSON.stringify({
        currentStep: 1,
        scriptText: project.scriptText,
        scenes: project.scenes,
        selectedStyle: project.selectedStyle,
        imageAspectRatio: project.imageAspectRatio,
        customStyle: project.customStyle,
      })
    );
    setLocation("/wizard");
  };

  const createNewProject = () => {
    // Limpar o estado do wizard
    localStorage.removeItem("storyboard_wizard_state");
    setLocation("/wizard");
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Meus Projetos</h1>
          <p className="text-gray-600">Gerencie seus storyboards criados com IA</p>
        </div>

        {/* Botão Novo Projeto */}
        <div className="mb-8">
          <Button
            onClick={createNewProject}
            className="gap-2 bg-indigo-600 hover:bg-indigo-700"
            size="lg"
          >
            <Plus className="w-5 h-5" />
            Novo Projeto
          </Button>
        </div>

        {/* Lista de Projetos */}
        {loading ? (
          <div className="text-center py-12">
            <p className="text-gray-600">Carregando projetos...</p>
          </div>
        ) : projects.length === 0 ? (
          <Card className="p-12 text-center">
            <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Nenhum projeto criado ainda
            </h3>
            <p className="text-gray-600 mb-6">
              Comece criando seu primeiro storyboard com IA
            </p>
            <Button
              onClick={createNewProject}
              className="gap-2 bg-indigo-600 hover:bg-indigo-700"
            >
              <Plus className="w-5 h-5" />
              Criar Primeiro Projeto
            </Button>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project) => (
              <Card key={project.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="p-6">
                  {/* Título */}
                  <h3 className="text-lg font-semibold text-gray-900 mb-2 truncate">
                    {project.name}
                  </h3>

                  {/* Informações */}
                  <div className="space-y-2 mb-4 text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      <span>{project.scenes.length} cenas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>{formatDate(project.updatedAt)}</span>
                    </div>
                    {project.selectedStyle && (
                      <div className="flex items-center gap-2">
                        <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-1 rounded">
                          {project.selectedStyle}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Preview do Roteiro */}
                  <p className="text-sm text-gray-600 mb-4 line-clamp-2 bg-gray-50 p-2 rounded">
                    {project.scriptText}
                  </p>

                  {/* Imagens Geradas */}
                  {project.generatedImages && project.generatedImages.length > 0 && (
                    <div className="mb-4 p-2 bg-green-50 rounded border border-green-200">
                      <p className="text-xs font-semibold text-green-900">
                        ✓ {project.generatedImages.length} cenas com imagens
                      </p>
                    </div>
                  )}

                  {/* Ações */}
                  <div className="flex gap-2">
                    <Button
                      onClick={() => openProject(project)}
                      variant="default"
                      size="sm"
                      className="flex-1 gap-2 bg-indigo-600 hover:bg-indigo-700"
                    >
                      <Eye className="w-4 h-4" />
                      Abrir
                    </Button>
                    <Button
                      onClick={() => deleteProject(project.id)}
                      variant="destructive"
                      size="sm"
                      className="gap-2"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
