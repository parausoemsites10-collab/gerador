import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChevronLeft, ChevronRight, Home } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import Step1ScriptInput from "@/components/wizard/Step1ScriptInput";
import Step2SceneEditor from "@/components/wizard/Step2SceneEditor";
import Step3StyleSelection from "@/components/wizard/Step3StyleSelection";
import Step4ImageGeneration from "@/components/wizard/Step4ImageGeneration";

const STORAGE_KEY = "storyboard_wizard_state";

interface WizardState {
  currentStep: number;
  scriptText: string;
  scenes: Array<{ id: string; text: string }>;
  selectedStyle: string;
  imageAspectRatio: string;
  customStyle?: string;
  generatedImages?: Array<{
    sceneId: string;
    images: string[];
    prompt?: string;
  }>;
}

export default function StoryboardWizard() {
  const [, setLocation] = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const [scriptText, setScriptText] = useState("");
  const [scenes, setScenes] = useState<Array<{ id: string; text: string }>>([]);
  const [selectedStyle, setSelectedStyle] = useState("");
  const [imageAspectRatio, setImageAspectRatio] = useState("16:9");
  const [customStyle, setCustomStyle] = useState("");
  const [generatedImages, setGeneratedImages] = useState<Array<{
    sceneId: string;
    images: string[];
    prompt?: string;
    isGenerating?: boolean;
    error?: string;
    editingPrompt?: boolean;
    editedPrompt?: string;
  }>>([]);

  // Load state from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const state = JSON.parse(saved) as WizardState;
        setCurrentStep(state.currentStep);
        setScriptText(state.scriptText);
        setScenes(state.scenes);
        setSelectedStyle(state.selectedStyle);
        setImageAspectRatio(state.imageAspectRatio);
        setCustomStyle(state.customStyle || "");
      } catch (error) {
        console.error("Erro ao carregar estado:", error);
      }
    }
  }, []);

  // Save state to localStorage whenever it changes
  useEffect(() => {
    const state: WizardState = {
      currentStep,
      scriptText,
      scenes,
      selectedStyle,
      imageAspectRatio,
      customStyle,
      generatedImages,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [currentStep, scriptText, scenes, selectedStyle, imageAspectRatio, customStyle, generatedImages]);

  const handleNextStep = () => {
    if (currentStep === 1 && scriptText.trim()) {
      const parsedScenes = scriptText
        .split("\n")
        .filter((line) => line.trim())
        .map((text, index) => ({
          id: `scene-${index}`,
          text: text.trim(),
        }));
      setScenes(parsedScenes);
      setCurrentStep(2);
    } else if (currentStep === 2) {
      setCurrentStep(3);
    } else if (currentStep === 3 && customStyle.trim()) {
      setCurrentStep(4);
    } else if (currentStep === 3 && !customStyle.trim()) {
      toast.error("Selecione ou crie um estilo antes de continuar");
    }
  };

  const handlePreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleFinishProject = () => {
    try {
      const projectId = `project-${Date.now()}`;
      const newProject = {
        id: projectId,
        name: `Projeto ${new Date().toLocaleDateString("pt-BR")}`,
        scriptText,
        scenes,
        selectedStyle,
        imageAspectRatio,
        customStyle,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const stored = localStorage.getItem("storyboard_projects");
      const projects = stored ? JSON.parse(stored) : [];
      projects.push(newProject);
      localStorage.setItem("storyboard_projects", JSON.stringify(projects));
      localStorage.removeItem(STORAGE_KEY);
      
      toast.success("Projeto salvo com sucesso!");
      setTimeout(() => {
        setLocation("/");
      }, 500);
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : "Erro desconhecido";
      console.error("Erro ao salvar projeto:", error);
      toast.error(`Erro ao salvar: ${errorMsg}`);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <Step1ScriptInput scriptText={scriptText} onScriptChange={setScriptText} />;
      case 2:
        return <Step2SceneEditor scenes={scenes} onScenesChange={setScenes} />;
      case 3:
        return (
          <Step3StyleSelection
            selectedStyle={selectedStyle}
            imageAspectRatio={imageAspectRatio}
            customStyle={customStyle}
            onStyleChange={setSelectedStyle}
            onAspectRatioChange={setImageAspectRatio}
            onCustomStyleChange={setCustomStyle}
          />
        );
      case 4:
        return (
          <Step4ImageGeneration
            scenes={scenes}
            style={customStyle}
            imageAspectRatio={imageAspectRatio}
            customStyle={customStyle}
            onImagesGenerated={setGeneratedImages}
          />
        );
      default:
        return null;
    }
  };

  const getStepTitle = () => {
    const titles = ["", "Roteiro", "Cenas", "Estilo", "Gerar Imagens"];
    return titles[currentStep] || "";
  };

  const getStepDescription = () => {
    const descriptions = [
      "",
      "Escreva o roteiro da sua história. Cada linha será uma cena.",
      "Edite, exclua ou reordene as cenas conforme necessário.",
      "Escolha um estilo visual para suas imagens.",
      "Gere as 4 imagens para cada cena usando Gemini e ImageFX.",
    ];
    return descriptions[currentStep] || "";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <div className="border-b border-slate-800 sticky top-0 z-40 bg-slate-950/95 backdrop-blur">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              onClick={() => setLocation("/")}
              variant="ghost"
              size="icon"
              className="text-slate-400 hover:text-white"
            >
              <Home className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-white">Storyboard AI</h1>
            </div>
          </div>
          <div className="text-sm text-slate-400">
            Passo {currentStep} de 4
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Step Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {[1, 2, 3, 4].map((step) => (
            <button
              key={step}
              onClick={() => {
                if (step < currentStep || (step === currentStep)) {
                  setCurrentStep(step);
                } else if (step === currentStep + 1 && currentStep === 1 && scriptText.trim()) {
                  const parsedScenes = scriptText
                    .split("\n")
                    .filter((line) => line.trim())
                    .map((text, index) => ({
                      id: `scene-${index}`,
                      text: text.trim(),
                    }));
                  setScenes(parsedScenes);
                  setCurrentStep(step);
                } else if (step === currentStep + 1 && currentStep === 3 && selectedStyle) {
                  setCurrentStep(step);
                } else if (step === currentStep + 1 && currentStep !== 1 && currentStep !== 3) {
                  setCurrentStep(step);
                }
              }}
              className={`flex items-center justify-center w-12 h-12 rounded-lg font-semibold transition-all whitespace-nowrap px-4 ${ step === currentStep
                  ? "bg-indigo-600 text-white"
                  : step < currentStep
                    ? "bg-green-600/20 text-green-400 border border-green-600/30"
                    : "bg-slate-800 text-slate-400 border border-slate-700 hover:border-slate-600"
              }`}
            >
              {step < currentStep ? "✓" : step}
            </button>
          ))}
        </div>

        {/* Card */}
        <Card className="bg-slate-800 border-slate-700 mb-8">
          <CardHeader>
            <CardTitle className="text-white">{getStepTitle()}</CardTitle>
            <CardDescription className="text-slate-400">{getStepDescription()}</CardDescription>
          </CardHeader>
          <CardContent>
            {renderStep()}
          </CardContent>
        </Card>

        {/* Bottom Navigation */}
        <div className="flex justify-end gap-3 fixed bottom-6 right-6">
          <Button
            onClick={handlePreviousStep}
            disabled={currentStep === 1}
            variant="outline"
            className="border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Anterior
          </Button>

          {currentStep === 4 ? (
            <Button
              onClick={handleFinishProject}
              className="gap-2 bg-green-600 hover:bg-green-700 text-white"
            >
              Finalizar
            </Button>
          ) : (
            <Button
              onClick={handleNextStep}
              disabled={
                (currentStep === 1 && !scriptText.trim()) ||
                (currentStep === 3 && !selectedStyle)
              }
              className="gap-2 bg-indigo-600 hover:bg-indigo-700 text-white"
            >
              Próximo
              <ChevronRight className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
