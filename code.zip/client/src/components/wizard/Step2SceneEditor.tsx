import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Trash2, GripVertical, Edit2, Check, X } from "lucide-react";

interface Scene {
  id: string;
  text: string;
}

interface Step2SceneEditorProps {
  scenes: Scene[];
  onScenesChange: (scenes: Scene[]) => void;
}

export default function Step2SceneEditor({ scenes, onScenesChange }: Step2SceneEditorProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState("");
  const [draggedId, setDraggedId] = useState<string | null>(null);

  const handleEdit = (id: string, text: string) => {
    setEditingId(id);
    setEditingText(text);
  };

  const handleSaveEdit = (id: string) => {
    const updatedScenes = scenes.map((scene) =>
      scene.id === id ? { ...scene, text: editingText } : scene
    );
    onScenesChange(updatedScenes);
    setEditingId(null);
    setEditingText("");
  };

  const handleDelete = (id: string) => {
    const updatedScenes = scenes.filter((scene) => scene.id !== id);
    onScenesChange(updatedScenes);
  };

  const handleDragStart = (id: string) => {
    setDraggedId(id);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (targetId: string) => {
    if (!draggedId || draggedId === targetId) return;

    const draggedIndex = scenes.findIndex((s) => s.id === draggedId);
    const targetIndex = scenes.findIndex((s) => s.id === targetId);

    const newScenes = [...scenes];
    const [draggedScene] = newScenes.splice(draggedIndex, 1);
    newScenes.splice(targetIndex, 0, draggedScene);

    onScenesChange(newScenes);
    setDraggedId(null);
  };

  return (
    <div className="space-y-4">
      <p className="text-sm text-gray-600">
        Você tem <strong>{scenes.length} cenas</strong>. Arraste para reordenar, edite ou exclua conforme necessário.
      </p>

      <div className="space-y-3 max-h-96 overflow-y-auto">
        {scenes.map((scene, index) => (
          <Card
            key={scene.id}
            draggable
            onDragStart={() => handleDragStart(scene.id)}
            onDragOver={handleDragOver}
            onDrop={() => handleDrop(scene.id)}
            className={`p-4 cursor-move transition-all ${
              draggedId === scene.id ? "opacity-50 bg-gray-100" : "hover:shadow-md"
            }`}
          >
            <div className="flex items-start gap-3">
              <GripVertical className="w-5 h-5 text-gray-400 mt-1 flex-shrink-0" />

              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-gray-500 mb-2">Cena {index + 1}</div>

                {editingId === scene.id ? (
                  <Textarea
                    value={editingText}
                    onChange={(e) => setEditingText(e.target.value)}
                    className="min-h-20 mb-2"
                  />
                ) : (
                  <p className="text-gray-800 break-words">{scene.text}</p>
                )}
              </div>

              <div className="flex gap-2 flex-shrink-0">
                {editingId === scene.id ? (
                  <>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleSaveEdit(scene.id)}
                      className="text-green-600 hover:text-green-700"
                    >
                      <Check className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setEditingId(null)}
                      className="text-gray-600 hover:text-gray-700"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </>
                ) : (
                  <>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEdit(scene.id, scene.text)}
                      className="text-blue-600 hover:text-blue-700"
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(scene.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
