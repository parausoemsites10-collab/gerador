import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Trash2, Plus, Check } from "lucide-react";
import { toast } from "sonner";

interface Step3StyleSelectionProps {
  selectedStyle: string;
  imageAspectRatio: string;
  customStyle: string;
  onStyleChange: (style: string) => void;
  onAspectRatioChange: (ratio: string) => void;
  onCustomStyleChange: (style: string) => void;
}

interface CustomStyle {
  id: string;
  name: string;
  description: string;
}

const ASPECT_RATIOS = [
  { id: "16:9", label: "16:9 (Widescreen)" },
  { id: "9:16", label: "9:16 (Vertical)" },
  { id: "1:1", label: "1:1 (Quadrado)" },
  { id: "4:3", label: "4:3 (Padrão)" },
  { id: "21:9", label: "21:9 (Ultra Wide)" },
];

export default function Step3StyleSelection({
  selectedStyle,
  imageAspectRatio,
  customStyle,
  onStyleChange,
  onAspectRatioChange,
  onCustomStyleChange,
}: Step3StyleSelectionProps) {
  const [styles, setStyles] = useState<CustomStyle[]>([]);
  const [showAddStyle, setShowAddStyle] = useState(false);
  const [newStyleName, setNewStyleName] = useState("");
  const [newStyleDesc, setNewStyleDesc] = useState("");

  // Load styles from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("customStyles");
    if (saved) {
      try {
        setStyles(JSON.parse(saved));
      } catch (error) {
        console.error("Erro ao carregar estilos:", error);
      }
    }
  }, []);

  const handleAddStyle = () => {
    if (!newStyleName.trim()) {
      toast.error("Nome do estilo é obrigatório");
      return;
    }
    if (!newStyleDesc.trim()) {
      toast.error("Descrição do estilo é obrigatória");
      return;
    }

    const newStyle: CustomStyle = {
      id: `style-${Date.now()}`,
      name: newStyleName,
      description: newStyleDesc,
    };

    const updated = [...styles, newStyle];
    setStyles(updated);
    localStorage.setItem("customStyles", JSON.stringify(updated));
    
    // Select the new style
    onStyleChange(newStyle.id);
    onCustomStyleChange(newStyleDesc);
    
    // Reset form
    setNewStyleName("");
    setNewStyleDesc("");
    setShowAddStyle(false);
    toast.success("Estilo criado com sucesso!");
  };

  const handleDeleteStyle = (styleId: string) => {
    const updated = styles.filter((s) => s.id !== styleId);
    setStyles(updated);
    localStorage.setItem("customStyles", JSON.stringify(updated));
    
    if (selectedStyle === styleId) {
      onStyleChange("");
      onCustomStyleChange("");
    }
    toast.success("Estilo deletado com sucesso!");
  };

  const handleSelectStyle = (style: CustomStyle) => {
    onStyleChange(style.id);
    onCustomStyleChange(style.description);
  };

  return (
    <div className="space-y-6">
      {/* Aspect Ratio Selection */}
      <div>
        <label className="block text-sm font-medium text-slate-200 mb-3">
          Proporção das Imagens
        </label>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
          {ASPECT_RATIOS.map((ratio) => (
            <button
              key={ratio.id}
              onClick={() => onAspectRatioChange(ratio.id)}
              className={`p-3 rounded-lg border transition-all text-sm font-medium ${
                imageAspectRatio === ratio.id
                  ? "bg-indigo-600 border-indigo-600 text-white"
                  : "bg-slate-700 border-slate-600 text-slate-300 hover:border-slate-500"
              }`}
            >
              {ratio.label}
            </button>
          ))}
        </div>
      </div>

      {/* Custom Styles */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <label className="block text-sm font-medium text-slate-200">
            Seus Estilos Personalizados
          </label>
          <Button
            onClick={() => setShowAddStyle(!showAddStyle)}
            size="sm"
            className="gap-2 bg-indigo-600 hover:bg-indigo-700 text-white"
          >
            <Plus className="w-4 h-4" />
            Novo Estilo
          </Button>
        </div>

        {/* Add New Style Form */}
        {showAddStyle && (
          <Card className="bg-slate-700 border-slate-600 p-4 mb-4">
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-slate-200 mb-1">
                  Nome do Estilo
                </label>
                <Input
                  value={newStyleName}
                  onChange={(e) => setNewStyleName(e.target.value)}
                  placeholder="Ex: Cyberpunk Neon"
                  className="bg-slate-600 border-slate-500 text-white placeholder-slate-400"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-200 mb-1">
                  Descrição do Estilo
                </label>
                <textarea
                  value={newStyleDesc}
                  onChange={(e) => setNewStyleDesc(e.target.value)}
                  placeholder="Descreva o estilo que deseja usar nos prompts..."
                  rows={3}
                  className="w-full px-3 py-2 bg-slate-600 border border-slate-500 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={handleAddStyle}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                  size="sm"
                >
                  Criar Estilo
                </Button>
                <Button
                  onClick={() => setShowAddStyle(false)}
                  variant="outline"
                  className="flex-1 border-slate-500 text-slate-300 hover:bg-slate-600"
                  size="sm"
                >
                  Cancelar
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Styles Grid */}
        {styles.length === 0 ? (
          <div className="text-center py-8 text-slate-400">
            <p className="mb-3">Nenhum estilo criado ainda</p>
            <p className="text-sm">Clique em "Novo Estilo" para criar seu primeiro estilo</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {styles.map((style) => (
              <Card
                key={style.id}
                className={`bg-slate-700 border transition-all cursor-pointer p-4 ${
                  selectedStyle === style.id
                    ? "border-indigo-600 ring-2 ring-indigo-600/50"
                    : "border-slate-600 hover:border-slate-500"
                }`}
                onClick={() => handleSelectStyle(style)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-white">{style.name}</h3>
                      {selectedStyle === style.id && (
                        <Check className="w-4 h-4 text-indigo-400" />
                      )}
                    </div>
                    <p className="text-sm text-slate-400 line-clamp-2">
                      {style.description}
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteStyle(style.id);
                    }}
                    className="ml-2 p-2 text-red-400 hover:bg-red-600/20 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
