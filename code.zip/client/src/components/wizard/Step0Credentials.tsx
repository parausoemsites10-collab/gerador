import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { AlertCircle, CheckCircle2, Lock } from "lucide-react";
import { toast } from "sonner";

interface Step0CredentialsProps {
  onCredentialsValid: (googleApiKey: string, imageFxCookie: string) => void;
}

export default function Step0Credentials({ onCredentialsValid }: Step0CredentialsProps) {
  const [googleApiKey, setGoogleApiKey] = useState("");
  const [imageFxCookie, setImageFxCookie] = useState("");
  const [isValidating, setIsValidating] = useState(false);
  const [hasGoogleKey, setHasGoogleKey] = useState(false);
  const [hasCookie, setHasCookie] = useState(false);

  // Load credentials from localStorage on mount
  useEffect(() => {
    const savedGoogleKey = localStorage.getItem("googleApiKey") || "";
    const savedImageFxCookie = localStorage.getItem("imageFxCookie") || "";
    setGoogleApiKey(savedGoogleKey);
    setImageFxCookie(savedImageFxCookie);
    setHasGoogleKey(!!savedGoogleKey);
    setHasCookie(!!savedImageFxCookie);
  }, []);

  const handleContinue = async () => {
    console.log("[Step0] handleContinue chamado");
    console.log("[Step0] googleApiKey:", googleApiKey ? googleApiKey.substring(0, 10) + "..." : "VAZIO");
    console.log("[Step0] imageFxCookie:", imageFxCookie ? imageFxCookie.substring(0, 10) + "..." : "VAZIO");

    // Use provided values or fallback to mock values for testing
    const finalGoogleKey = googleApiKey.trim() || "mock-google-api-key-for-testing";
    const finalImageFxCookie = imageFxCookie.trim() || "mock-imagefx-cookie-for-testing";

    setIsValidating(true);

    try {
      // Save to localStorage
      localStorage.setItem("googleApiKey", finalGoogleKey);
      localStorage.setItem("imageFxCookie", finalImageFxCookie);
      console.log("[Step0] Credenciais salvas no localStorage");
      console.log("[Step0] googleApiKey salva:", finalGoogleKey.substring(0, 20) + "...");
      console.log("[Step0] imageFxCookie salva:", finalImageFxCookie.substring(0, 20) + "...");

      // Verify they were saved
      const verify1 = localStorage.getItem("googleApiKey");
      const verify2 = localStorage.getItem("imageFxCookie");
      console.log("[Step0] Verificação - googleApiKey salva:", !!verify1);
      console.log("[Step0] Verificação - imageFxCookie salva:", !!verify2);

      toast.success("Credenciais salvas com sucesso!");
      console.log("[Step0] Chamando onCredentialsValid");
      onCredentialsValid(finalGoogleKey, finalImageFxCookie);
    } catch (error) {
      console.error("[Step0] Erro:", error);
      toast.error("Erro ao salvar credenciais");
    } finally {
      setIsValidating(false);
    }
  };

  // Always allow continuing (with or without credentials)
  const isValid = true;

  useEffect(() => {
    console.log("[Step0] isValid:", isValid);
    console.log("[Step0] googleApiKey length:", googleApiKey.length);
    console.log("[Step0] imageFxCookie length:", imageFxCookie.length);
  }, [googleApiKey, imageFxCookie, isValid]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="flex justify-center mb-4">
          <Lock className="w-12 h-12 text-indigo-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Configuração de Credenciais</h2>
        <p className="text-gray-600">
          Para usar o gerador de storyboard, você precisa fornecer suas credenciais de API
        </p>
      </div>

      {/* Google API Key */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {hasGoogleKey && <CheckCircle2 className="w-5 h-5 text-green-600" />}
            Google AI Studio API Key
          </CardTitle>
          <CardDescription>
            Necessária para processar roteiros e gerar prompts de imagem com Gemini
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="googleApiKey">Chave de API</Label>
            <Input
              id="googleApiKey"
              type="password"
              placeholder="Insira sua chave de API do Google AI Studio"
              value={googleApiKey}
              onChange={(e) => setGoogleApiKey(e.target.value)}
              className="mt-2 font-mono text-sm"
            />
            <p className="text-xs text-gray-500 mt-2">
              Obtenha sua chave gratuitamente em{" "}
              <a
                href="https://ai.google.dev"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline font-semibold"
              >
                ai.google.dev
              </a>
            </p>
          </div>
        </CardContent>
      </Card>

      {/* ImageFX Cookie */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {hasCookie && <CheckCircle2 className="w-5 h-5 text-green-600" />}
            ImageFX Cookie
          </CardTitle>
          <CardDescription>
            Necessária para gerar imagens usando a API do ImageFX
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="imageFxCookie">Cookie de Autenticação</Label>
            <Textarea
              id="imageFxCookie"
              placeholder="Cole aqui o cookie completo do Google obtido em labs.google.com/fx"
              value={imageFxCookie}
              onChange={(e) => setImageFxCookie(e.target.value)}
              className="mt-2 font-mono text-xs"
              rows={4}
            />
            <div className="mt-3 space-y-2">
              <p className="text-xs font-semibold text-gray-700">Como obter o cookie:</p>
              <ol className="text-xs text-gray-600 space-y-1 list-decimal list-inside">
                <li>
                  Abra{" "}
                  <a
                    href="https://labs.google.com/fx"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline"
                  >
                    labs.google.com/fx
                  </a>{" "}
                  (faça login se necessário)
                </li>
                <li>Pressione CTRL + SHIFT + I para abrir o console</li>
                <li>Clique na aba "Network"</li>
                <li>Pressione CTRL + R para recarregar a página</li>
                <li>Clique em "image-fx" na lista de requisições</li>
                <li>Vá para "Request Headers" e copie o valor completo de "Cookie"</li>
              </ol>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Warning */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-amber-800">
          <p className="font-semibold mb-1">⚠️ Segurança</p>
          <p>
            Suas credenciais são armazenadas localmente no seu navegador. Nunca compartilhe suas
            chaves de API ou cookies com terceiros.
          </p>
        </div>
      </div>

      {/* Continue Button */}
      <Button
        onClick={handleContinue}
        disabled={!isValid || isValidating}
        className="w-full gap-2 bg-indigo-600 hover:bg-indigo-700 h-12 text-base"
        size="lg"
      >
        {isValidating ? "Validando..." : "Continuar para o Wizard"}
      </Button>
    </div>
  );
}
