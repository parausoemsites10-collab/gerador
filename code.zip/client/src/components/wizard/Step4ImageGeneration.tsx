"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Loader2, Download, AlertCircle, CheckCircle2, Edit2, RotateCcw, Copy, Check } from "lucide-react"
import { toast } from "sonner"
import { trpc } from "@/lib/trpc"

interface Scene {
  id: string
  text: string
}

interface GeneratedImage {
  sceneId: string
  images: string[]
  isGenerating: boolean
  error?: string
  prompt?: string
  editingPrompt?: boolean
  editedPrompt?: string
}

interface Step4ImageGenerationProps {
  scenes: Scene[]
  style: string
  imageAspectRatio?: string
  customStyle?: string
  onFinish?: () => void
  onImagesGenerated?: (images: GeneratedImage[]) => void
}

export default function Step4ImageGeneration({
  scenes,
  style,
  imageAspectRatio = "16:9",
  customStyle = "",
  onFinish,
  onImagesGenerated,
}: Step4ImageGenerationProps) {
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([])
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null)

  useEffect(() => {
    if (onImagesGenerated) {
      onImagesGenerated(generatedImages)
    }
  }, [generatedImages, onImagesGenerated])

  const [isGenerating, setIsGenerating] = useState(false)
  const [currentSceneIndex, setCurrentSceneIndex] = useState(-1)
  const [debugLogs, setDebugLogs] = useState<string[]>([])
  const [isComplete, setIsComplete] = useState(false)

  const generateMutation = trpc.storyboard.generateStoryboardImages.useMutation()

  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString()
    const logMessage = `[${timestamp}] ${message}`
    setDebugLogs((prev) => [...prev, logMessage])
    console.log(logMessage)
  }

  const copyPromptToClipboard = (prompt: string, sceneIndex: number) => {
    navigator.clipboard
      .writeText(prompt)
      .then(() => {
        setCopiedIndex(sceneIndex)
        toast.success("Prompt copiado para a área de transferência!")
        setTimeout(() => setCopiedIndex(null), 2000)
      })
      .catch(() => {
        toast.error("Erro ao copiar prompt")
      })
  }

  const generateSingleScene = async (sceneIndex: number, imageFxCookie: string, customPrompt?: string) => {
    try {
      addLog(`🎬 Gerando imagens para Cena ${sceneIndex + 1}...`)
      setCurrentSceneIndex(sceneIndex)

      const scene = scenes[sceneIndex]
      const result = await generateMutation.mutateAsync({
        scenes: [
          {
            sceneId: scene.id,
            sceneDescription: scene.text,
          },
        ],
        style,
        imageFxCookie,
      })

      if (result.success && result.results && result.results.length > 0) {
        const sceneResult = result.results[0]
        addLog(`✓ Cena ${sceneIndex + 1}: ${sceneResult.images.length} imagens geradas`)

        setGeneratedImages((prev) => {
          const updated = [...prev]
          updated[sceneIndex] = {
            sceneId: sceneResult.sceneId,
            images: sceneResult.images,
            isGenerating: false,
            error: sceneResult.error,
            prompt: sceneResult.prompt,
            editingPrompt: false,
            editedPrompt: sceneResult.prompt,
          }
          return updated
        })

        // Wait for random delay (11-15 seconds) before next scene
        if (sceneIndex < scenes.length - 1) {
          const delay = Math.floor(Math.random() * 4000) + 11000
          addLog(`⏳ Aguardando ${(delay / 1000).toFixed(1)}s antes da próxima cena...`)
          await new Promise((resolve) => setTimeout(resolve, delay))
        }
      } else {
        const errorMsg = result.results?.[0]?.error || "Erro desconhecido"
        addLog(`❌ Erro na cena ${sceneIndex + 1}: ${errorMsg}`)
        setGeneratedImages((prev) => {
          const updated = [...prev]
          updated[sceneIndex] = {
            sceneId: scene.id,
            images: [],
            isGenerating: false,
            error: errorMsg,
          }
          return updated
        })
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Erro desconhecido"
      addLog(`❌ Erro na cena ${sceneIndex + 1}: ${errorMessage}`)
      setGeneratedImages((prev) => {
        const updated = [...prev]
        updated[sceneIndex] = {
          sceneId: scenes[sceneIndex].id,
          images: [],
          isGenerating: false,
          error: errorMessage,
        }
        return updated
      })
    }
  }

  const startGeneration = async () => {
    addLog("🚀 Iniciando geração de storyboard...")

    if (!style || !style.trim()) {
      const errorMsg = "❌ Estilo não foi selecionado"
      addLog(errorMsg)
      toast.error("Selecione um estilo antes de gerar imagens")
      return
    }

    const imageFxCookie = localStorage.getItem("imageFxCookie")
    if (!imageFxCookie || imageFxCookie.trim().length < 10) {
      const errorMsg = "❌ Cookie do ImageFX não configurado ou inválido"
      addLog(errorMsg)
      toast.error("Configure um cookie válido do ImageFX nas configurações")
      return
    }

    const googleApiKey = localStorage.getItem("googleApiKey")
    if (!googleApiKey || googleApiKey.trim().length < 10) {
      const errorMsg = "❌ Chave API do Google não configurada ou inválida"
      addLog(errorMsg)
      toast.error("Configure uma chave API válida do Google nas configurações")
      return
    }

    addLog(`✓ Credenciais validadas`)
    addLog(`✓ Número de cenas: ${scenes.length}`)
    addLog(`✓ Estilo selecionado: ${style.substring(0, 50)}...`)
    addLog(`✓ Proporção: ${imageAspectRatio}`)
    addLog(`✓ Cookie length: ${imageFxCookie.length} chars`)
    addLog(`✓ API Key length: ${googleApiKey.length} chars`)

    setIsGenerating(true)
    setIsComplete(false)
    setGeneratedImages(
      scenes.map((scene) => ({
        sceneId: scene.id,
        images: [],
        isGenerating: true,
      })),
    )

    try {
      for (let i = 0; i < scenes.length; i++) {
        await generateSingleScene(i, imageFxCookie)
      }

      addLog("🎉 Geração concluída!")
      setIsComplete(true)
      toast.success("✓ Geração finalizada! Você pode agora salvar o projeto.")
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Erro desconhecido"
      addLog(`❌ Erro durante geração: ${errorMessage}`)
      console.error("Erro completo:", error)
      toast.error(`Erro ao gerar storyboard: ${errorMessage}. Verifique os logs acima para mais detalhes.`)
    } finally {
      setIsGenerating(false)
      setCurrentSceneIndex(-1)
      addLog("⏹️ Processo finalizado")
    }
  }

  const refakeScene = async (sceneIndex: number) => {
    const imageFxCookie = localStorage.getItem("imageFxCookie")
    if (!imageFxCookie) {
      toast.error("Cookie do ImageFX não configurado")
      return
    }

    setGeneratedImages((prev) => {
      const updated = [...prev]
      updated[sceneIndex] = {
        sceneId: updated[sceneIndex].sceneId,
        images: [],
        isGenerating: true,
        error: undefined,
        prompt: updated[sceneIndex].prompt,
      }
      return updated
    })

    const customPrompt = generatedImages[sceneIndex]?.editedPrompt
    await generateSingleScene(sceneIndex, imageFxCookie, customPrompt)
  }

  const handleDownload = (imageUrl: string, sceneIndex: number, imageIndex: number) => {
    try {
      const link = document.createElement("a")
      link.href = imageUrl
      link.download = `storyboard-scene-${sceneIndex + 1}-image-${imageIndex + 1}.jpg`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      addLog(`📥 Imagem baixada: Cena ${sceneIndex + 1}, Imagem ${imageIndex + 1}`)
    } catch (error) {
      toast.error("Erro ao baixar imagem")
    }
  }

  return (
    <div className="space-y-6">
      {/* Debug Logs */}
      {debugLogs.length > 0 && (
        <Card className="p-4 bg-slate-900 text-slate-100 font-mono text-xs max-h-48 overflow-y-auto border-slate-700">
          <div className="space-y-1">
            {debugLogs.map((log, index) => (
              <div key={index} className="text-slate-300">
                {log}
              </div>
            ))}
          </div>
        </Card>
      )}

      {!isGenerating && generatedImages.length === 0 && (
        <div className="text-center py-12">
          <p className="text-slate-300 mb-4">Clique no botão abaixo para gerar as 4 imagens para cada cena</p>
          <Button onClick={startGeneration} className="gap-2 bg-indigo-600 hover:bg-indigo-700" size="lg">
            <Loader2 className="w-5 h-5" />
            Iniciar Geração de Imagens
          </Button>
        </div>
      )}

      {isGenerating && currentSceneIndex >= 0 && (
        <div className="bg-indigo-950 border border-indigo-700 rounded-lg p-4">
          <p className="text-sm text-indigo-100 font-semibold mb-2">
            ⏳ Gerando imagens da cena {currentSceneIndex + 1} de {scenes.length}...
          </p>
          <div className="mt-2 w-full bg-indigo-900 rounded-full h-2">
            <div
              className="bg-indigo-500 h-2 rounded-full transition-all"
              style={{
                width: `${((currentSceneIndex + 1) / scenes.length) * 100}%`,
              }}
            />
          </div>
          <p className="text-xs text-indigo-200 mt-2">Isso pode levar alguns minutos. Não feche a página.</p>
        </div>
      )}

      <div className="space-y-8">
        {generatedImages.map((generated, sceneIndex) => (
          <Card key={generated.sceneId} className="p-6 bg-slate-800 border-slate-700">
            <div className="mb-4 flex items-start justify-between">
              <div className="flex-1">
                <h3 className="font-semibold text-lg text-slate-100">
                  Cena {sceneIndex + 1}: {scenes[sceneIndex]?.text}
                </h3>
                {generated.prompt && !generated.editingPrompt && (
                  <div className="mt-3 p-3 bg-slate-700 rounded-lg border border-slate-600">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <p className="text-xs font-semibold text-slate-300 mb-1">Prompt Gerado:</p>
                        <p className="text-sm text-slate-200 leading-relaxed">{generated.prompt}</p>
                      </div>
                      <Button
                        onClick={() => copyPromptToClipboard(generated.prompt || "", sceneIndex)}
                        variant="outline"
                        size="sm"
                        className="flex-shrink-0 gap-2 border-slate-600 text-slate-300 hover:bg-slate-600"
                      >
                        {copiedIndex === sceneIndex ? (
                          <>
                            <Check className="w-4 h-4" />
                            Copiado
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4" />
                            Copiar
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
              {generated.images.length > 0 && !generated.error && (
                <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
              )}
            </div>

            {generated.isGenerating ? (
              <div className="flex flex-col items-center justify-center py-12 gap-3">
                <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
                <p className="text-sm text-slate-300">Gerando imagens...</p>
              </div>
            ) : generated.error ? (
              <div className="space-y-4">
                {generated.editingPrompt ? (
                  <div className="bg-slate-700 border border-slate-600 rounded-lg p-4 space-y-2">
                    <label className="block text-sm font-medium text-slate-200">Editar Prompt</label>
                    <textarea
                      value={generated.editedPrompt || generated.prompt || ""}
                      onChange={(e) => {
                        setGeneratedImages((prev) => {
                          const updated = [...prev]
                          updated[sceneIndex].editedPrompt = e.target.value
                          return updated
                        })
                      }}
                      className="w-full h-20 px-3 py-2 bg-slate-600 border border-slate-500 rounded-lg text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                    <div className="flex gap-2">
                      <Button
                        onClick={() => {
                          setGeneratedImages((prev) => {
                            const updated = [...prev]
                            updated[sceneIndex].editingPrompt = false
                            return updated
                          })
                          refakeScene(sceneIndex)
                        }}
                        className="bg-indigo-600 hover:bg-indigo-700"
                        size="sm"
                      >
                        Refazer com Novo Prompt
                      </Button>
                      <Button
                        onClick={() => {
                          setGeneratedImages((prev) => {
                            const updated = [...prev]
                            updated[sceneIndex].editingPrompt = false
                            return updated
                          })
                        }}
                        variant="outline"
                        size="sm"
                        className="border-slate-600 text-slate-300 hover:bg-slate-700"
                      >
                        Cancelar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="bg-red-950 border border-red-700 rounded-lg p-4 flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-red-200">❌ Erro ao gerar imagens</p>
                        <p className="text-sm text-red-300 mt-1">
                          Desculpe, ocorreu um problema ao gerar as imagens desta cena. Tente novamente.
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => refakeScene(sceneIndex)}
                        variant="outline"
                        size="sm"
                        className="gap-2 border-slate-600 text-slate-300 hover:bg-slate-700"
                      >
                        <RotateCcw className="w-4 h-4" />
                        Tentar Novamente
                      </Button>
                      <Button
                        onClick={() => {
                          setGeneratedImages((prev) => {
                            const updated = [...prev]
                            updated[sceneIndex].editingPrompt = true
                            return updated
                          })
                        }}
                        variant="outline"
                        size="sm"
                        className="gap-2 border-slate-600 text-slate-300 hover:bg-slate-700"
                      >
                        <Edit2 className="w-4 h-4" />
                        Editar Prompt
                      </Button>
                    </div>
                  </>
                )}
              </div>
            ) : generated.images.length > 0 ? (
              <div className="space-y-4">
                {/* Editar Prompt */}
                {generated.editingPrompt ? (
                  <div className="bg-slate-700 border border-slate-600 rounded-lg p-4 space-y-2">
                    <label className="block text-sm font-medium text-slate-200">Editar Prompt</label>
                    <textarea
                      value={generated.editedPrompt || ""}
                      onChange={(e) => {
                        setGeneratedImages((prev) => {
                          const updated = [...prev]
                          updated[sceneIndex].editedPrompt = e.target.value
                          return updated
                        })
                      }}
                      className="w-full h-20 px-3 py-2 bg-slate-600 border border-slate-500 rounded-lg text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                    <div className="flex gap-2">
                      <Button
                        onClick={() => {
                          setGeneratedImages((prev) => {
                            const updated = [...prev]
                            updated[sceneIndex].editingPrompt = false
                            return updated
                          })
                          refakeScene(sceneIndex)
                        }}
                        className="bg-indigo-600 hover:bg-indigo-700"
                        size="sm"
                      >
                        Refazer com Novo Prompt
                      </Button>
                      <Button
                        onClick={() => {
                          setGeneratedImages((prev) => {
                            const updated = [...prev]
                            updated[sceneIndex].editingPrompt = false
                            updated[sceneIndex].editedPrompt = generated.prompt
                            return updated
                          })
                        }}
                        variant="outline"
                        size="sm"
                        className="border-slate-600 text-slate-300 hover:bg-slate-700"
                      >
                        Cancelar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <Button
                      onClick={() => refakeScene(sceneIndex)}
                      variant="outline"
                      size="sm"
                      className="gap-2 border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      <RotateCcw className="w-4 h-4" />
                      Refazer Cena
                    </Button>
                    <Button
                      onClick={() => {
                        setGeneratedImages((prev) => {
                          const updated = [...prev]
                          updated[sceneIndex].editingPrompt = true
                          return updated
                        })
                      }}
                      variant="outline"
                      size="sm"
                      className="gap-2 border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      <Edit2 className="w-4 h-4" />
                      Editar Prompt
                    </Button>
                  </div>
                )}

                {/* Imagens */}
                <div className="grid grid-cols-2 gap-4">
                  {generated.images.map((imageUrl, imageIndex) => (
                    <div key={imageIndex} className="space-y-2">
                      <img
                        src={imageUrl || "/placeholder.svg"}
                        alt={`Cena ${sceneIndex + 1} Imagem ${imageIndex + 1}`}
                        className="w-full rounded-lg shadow-md object-cover aspect-video"
                      />
                      <Button
                        onClick={() => handleDownload(imageUrl, sceneIndex, imageIndex)}
                        variant="outline"
                        size="sm"
                        className="w-full gap-2 border-slate-600 text-slate-300 hover:bg-slate-700"
                      >
                        <Download className="w-4 h-4" />
                        Download
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <p className="text-slate-400 text-center py-8">Aguardando geração...</p>
            )}
          </Card>
        ))}
      </div>

      {/* Botão Finalizar */}
      {(isComplete || generatedImages.length > 0) && !isGenerating && (
        <div className="flex gap-2 justify-center pt-8 border-t border-slate-700">
          <Button
            onClick={() => {
              if (onFinish) {
                try {
                  onFinish()
                  toast.success("✓ Projeto salvo com sucesso!")
                } catch (error) {
                  const msg = error instanceof Error ? error.message : "Erro ao salvar"
                  toast.error("Erro ao salvar: " + msg)
                }
              }
            }}
            className="gap-2 bg-green-600 hover:bg-green-700"
            size="lg"
          >
            ✓ Finalizar e Salvar Projeto
          </Button>
        </div>
      )}
    </div>
  )
}
