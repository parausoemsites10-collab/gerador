import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface Step1ScriptInputProps {
  scriptText: string;
  onScriptChange: (text: string) => void;
}

export default function Step1ScriptInput({ scriptText, onScriptChange }: Step1ScriptInputProps) {
  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="script">Roteiro da História</Label>
        <Textarea
          id="script"
          placeholder="Escreva seu roteiro aqui. Cada linha será uma cena do storyboard.&#10;&#10;Exemplo:&#10;Um herói chega à cidade&#10;Ele encontra um misterioso artefato&#10;Uma batalha épica começa&#10;O herói vence e salva o dia"
          value={scriptText}
          onChange={(e) => onScriptChange(e.target.value)}
          className="min-h-64"
        />
        <p className="text-sm text-gray-500 mt-2">
          💡 Dica: Cada linha será convertida em uma cena. Pressione Enter para criar uma nova cena.
        </p>
      </div>

      {scriptText.trim() && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-sm font-medium text-blue-900">
            ✓ Seu roteiro será dividido em{" "}
            <strong>{scriptText.split("\n").filter((line) => line.trim()).length} cenas</strong>
          </p>
        </div>
      )}
    </div>
  );
}
