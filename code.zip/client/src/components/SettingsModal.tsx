import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { X, Check, AlertCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface SettingsModalProps {
  onClose: () => void;
}

export default function SettingsModal({ onClose }: SettingsModalProps) {
  const [apiKeys, setApiKeys] = useState("");
  const [imageFxCookie, setImageFxCookie] = useState("");
  const [validatingApiKey, setValidatingApiKey] = useState(false);
  const [validatingCookie, setValidatingCookie] = useState(false);
  const [apiKeyStatus, setApiKeyStatus] = useState<"valid" | "invalid" | "checking" | null>(null);
  const [cookieStatus, setCookieStatus] = useState<"valid" | "invalid" | "checking" | null>(null);

  const validateApiKeyMutation = trpc.storyboard.validateGoogleApiKey.useMutation();
  const validateCookieMutation = trpc.storyboard.validateImageFxCookie.useMutation();

  // Load settings from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("storyboard_settings");
    if (saved) {
      try {
        const settings = JSON.parse(saved);
        setApiKeys(settings.apiKeys || "");
        setImageFxCookie(settings.imageFxCookie || "");
      } catch (error) {
        console.error("Erro ao carregar configurações:", error);
      }
    }
  }, []);

  const handleValidateApiKey = async () => {
    if (!apiKeys.trim()) {
      toast.error("Insira pelo menos uma chave API");
      return;
    }

    setValidatingApiKey(true);
    setApiKeyStatus("checking");

    try {
      const keys = apiKeys
        .split("\n")
        .map((k) => k.trim())
        .filter((k) => k.length > 0);

      const result = await validateApiKeyMutation.mutateAsync({
        apiKeys: keys,
      });

      if (result.valid) {
        setApiKeyStatus("valid");
        toast.success("Chave API válida e funcionando!");
      } else {
        setApiKeyStatus("invalid");
        toast.error("Chave API inválida ou expirada");
      }
    } catch (error) {
      setApiKeyStatus("invalid");
      toast.error("Erro ao validar chave API");
    } finally {
      setValidatingApiKey(false);
    }
  };

  const handleValidateCookie = async () => {
    if (!imageFxCookie.trim()) {
      toast.error("Insira o cookie do ImageFX");
      return;
    }

    setValidatingCookie(true);
    setCookieStatus("checking");

    try {
      const result = await validateCookieMutation.mutateAsync({
        cookie: imageFxCookie,
      });

      if (result.valid) {
        setCookieStatus("valid");
        toast.success("Cookie válido e funcionando!");
      } else {
        setCookieStatus("invalid");
        toast.error("Cookie inválido ou expirado");
      }
    } catch (error) {
      setCookieStatus("invalid");
      toast.error("Erro ao validar cookie");
    } finally {
      setValidatingCookie(false);
    }
  };

  const handleSave = () => {
    if (!apiKeys.trim() || !imageFxCookie.trim()) {
      toast.error("Preencha todos os campos");
      return;
    }

    const settings = {
      apiKeys,
      imageFxCookie,
    };

    localStorage.setItem("storyboard_settings", JSON.stringify(settings));
    toast.success("Configurações salvas com sucesso!");
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-slate-800 border-slate-700 shadow-2xl">
        <div className="p-6 border-b border-slate-700 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-white">Configurações</h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
          {/* Google API Keys */}
          <div>
            <label className="block text-sm font-medium text-slate-200 mb-2">
              Chaves API do Google (uma por linha)
            </label>
            <Textarea
              value={apiKeys}
              onChange={(e) => {
                setApiKeys(e.target.value);
                setApiKeyStatus(null);
              }}
              placeholder="Cole suas chaves API do Google aqui, uma por linha..."
              className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 min-h-[120px]"
            />
            <div className="mt-2 flex items-center gap-2">
              <Button
                onClick={handleValidateApiKey}
                disabled={validatingApiKey || !apiKeys.trim()}
                size="sm"
                className="gap-2 bg-indigo-600 hover:bg-indigo-700"
              >
                {validatingApiKey ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Validando...
                  </>
                ) : (
                  "Validar Chaves"
                )}
              </Button>
              {apiKeyStatus === "valid" && (
                <div className="flex items-center gap-1 text-green-400">
                  <Check className="w-4 h-4" />
                  <span className="text-sm">Válida</span>
                </div>
              )}
              {apiKeyStatus === "invalid" && (
                <div className="flex items-center gap-1 text-red-400">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm">Inválida</span>
                </div>
              )}
              {apiKeyStatus === "checking" && (
                <div className="flex items-center gap-1 text-yellow-400">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="text-sm">Verificando...</span>
                </div>
              )}
            </div>
          </div>

          {/* ImageFX Cookie */}
          <div>
            <label className="block text-sm font-medium text-slate-200 mb-2">
              Cookie do ImageFX
            </label>
            <Textarea
              value={imageFxCookie}
              onChange={(e) => {
                setImageFxCookie(e.target.value);
                setCookieStatus(null);
              }}
              placeholder="Cole o cookie do ImageFX aqui..."
              className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 min-h-[100px]"
            />
            <div className="mt-2 flex items-center gap-2">
              <Button
                onClick={handleValidateCookie}
                disabled={validatingCookie || !imageFxCookie.trim()}
                size="sm"
                className="gap-2 bg-indigo-600 hover:bg-indigo-700"
              >
                {validatingCookie ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Validando...
                  </>
                ) : (
                  "Validar Cookie"
                )}
              </Button>
              {cookieStatus === "valid" && (
                <div className="flex items-center gap-1 text-green-400">
                  <Check className="w-4 h-4" />
                  <span className="text-sm">Válido</span>
                </div>
              )}
              {cookieStatus === "invalid" && (
                <div className="flex items-center gap-1 text-red-400">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm">Inválido</span>
                </div>
              )}
              {cookieStatus === "checking" && (
                <div className="flex items-center gap-1 text-yellow-400">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="text-sm">Verificando...</span>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-slate-700 flex items-center justify-end gap-3">
          <Button
            onClick={onClose}
            variant="outline"
            className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600"
          >
            Cancelar
          </Button>
          <Button
            onClick={handleSave}
            className="gap-2 bg-indigo-600 hover:bg-indigo-700 text-white"
          >
            <Check className="w-4 h-4" />
            Salvar Configurações
          </Button>
        </div>
      </Card>
    </div>
  );
}
