import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { X, Loader2, Check, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface CredentialsModalProps {
  onClose: () => void;
  onConfirm: () => void;
}

export default function CredentialsModal({ onClose, onConfirm }: CredentialsModalProps) {
  const [googleApiKey, setGoogleApiKey] = useState("");
  const [imageFxCookie, setImageFxCookie] = useState("");
  const [validating, setValidating] = useState(false);
  const [apiKeyValid, setApiKeyValid] = useState<boolean | null>(null);
  const [cookieValid, setCookieValid] = useState<boolean | null>(null);

  const validateApiKeyMutation = trpc.storyboard.validateGoogleApiKey.useMutation();
  const validateCookieMutation = trpc.storyboard.validateImageFxCookie.useMutation();

  // Load credentials from settings on mount
  useEffect(() => {
    const settings = localStorage.getItem("storyboard_settings");
    if (settings) {
      try {
        const parsed = JSON.parse(settings);
        if (parsed.apiKeys) {
          setGoogleApiKey(parsed.apiKeys.split("\n")[0] || "");
        }
        if (parsed.imageFxCookie) {
          setImageFxCookie(parsed.imageFxCookie);
        }
      } catch (error) {
        console.error("Erro ao carregar configurações:", error);
      }
    }

    // Also check localStorage for direct credentials (legacy)
    const legacyApiKey = localStorage.getItem("googleApiKey");
    const legacyCookie = localStorage.getItem("imageFxCookie");
    if (legacyApiKey && !googleApiKey) setGoogleApiKey(legacyApiKey);
    if (legacyCookie && !imageFxCookie) setImageFxCookie(legacyCookie);
  }, []);

  const handleValidateCredentials = async () => {
    if (!googleApiKey.trim()) {
      toast.error("Insira a chave API do Google");
      return;
    }
    if (!imageFxCookie.trim()) {
      toast.error("Insira o cookie do ImageFX");
      return;
    }

    setValidating(true);
    setApiKeyValid(null);
    setCookieValid(null);

    try {
      // Validate API Key
      const apiKeyResult = await validateApiKeyMutation.mutateAsync({
        apiKeys: [googleApiKey],
      });
      setApiKeyValid(apiKeyResult.valid);

      // Validate Cookie
      const cookieResult = await validateCookieMutation.mutateAsync({
        cookie: imageFxCookie,
      });
      setCookieValid(cookieResult.valid);

      if (apiKeyResult.valid && cookieResult.valid) {
        toast.success("Credenciais validadas com sucesso!");
        // Save to localStorage
        localStorage.setItem("googleApiKey", googleApiKey);
        localStorage.setItem("imageFxCookie", imageFxCookie);
        onConfirm();
      } else {
        if (!apiKeyResult.valid) {
          toast.error("Chave API do Google inválida ou expirada");
        }
        if (!cookieResult.valid) {
          toast.error("Cookie do ImageFX inválido ou expirado");
        }
      }
    } catch (error) {
      toast.error("Erro ao validar credenciais");
      console.error("Validation error:", error);
    } finally {
      setValidating(false);
    }
  };

  const handleSkipValidation = () => {
    if (!googleApiKey.trim()) {
      toast.error("Insira a chave API do Google");
      return;
    }
    if (!imageFxCookie.trim()) {
      toast.error("Insira o cookie do ImageFX");
      return;
    }

    localStorage.setItem("googleApiKey", googleApiKey);
    localStorage.setItem("imageFxCookie", imageFxCookie);
    toast.success("Credenciais salvas!");
    onConfirm();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-slate-800 border border-slate-700 rounded-lg shadow-2xl w-full max-w-md mx-4">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <h2 className="text-xl font-bold text-white">Configurar Credenciais</h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-200 mb-2">
              Chave API do Google AI Studio
            </label>
            <div className="flex gap-2">
              <input
                type="password"
                value={googleApiKey}
                onChange={(e) => {
                  setGoogleApiKey(e.target.value);
                  setApiKeyValid(null);
                }}
                placeholder="Insira sua chave API..."
                className="flex-1 px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-600"
              />
              {apiKeyValid === true && (
                <div className="flex items-center text-green-400">
                  <Check className="w-5 h-5" />
                </div>
              )}
              {apiKeyValid === false && (
                <div className="flex items-center text-red-400">
                  <AlertCircle className="w-5 h-5" />
                </div>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Obtenha em: https://aistudio.google.com/app/apikey
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-200 mb-2">
              Cookie do ImageFX
            </label>
            <div className="flex gap-2">
              <textarea
                value={imageFxCookie}
                onChange={(e) => {
                  setImageFxCookie(e.target.value);
                  setCookieValid(null);
                }}
                placeholder="Insira seu cookie..."
                rows={3}
                className="flex-1 px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none"
              />
              {cookieValid === true && (
                <div className="flex items-center text-green-400">
                  <Check className="w-5 h-5" />
                </div>
              )}
              {cookieValid === false && (
                <div className="flex items-center text-red-400">
                  <AlertCircle className="w-5 h-5" />
                </div>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Obtenha do seu navegador: DevTools → Application → Cookies
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex flex-col gap-3 p-6 border-t border-slate-700">
          <Button
            onClick={handleValidateCredentials}
            disabled={validating || !googleApiKey.trim() || !imageFxCookie.trim()}
            className="w-full gap-2 bg-indigo-600 hover:bg-indigo-700 text-white"
          >
            {validating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Validando...
              </>
            ) : (
              "Validar e Continuar"
            )}
          </Button>

          <div className="flex gap-3">
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleSkipValidation}
              variant="outline"
              className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              Pular Validação
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
