# Integração com Google Gemini API

## Informações Coletadas

### Instalação
\`\`\`bash
npm install @google/generative-ai
\`\`\`

### Configuração Básica
\`\`\`javascript
import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

const response = await model.generateContent("Your prompt here");
console.log(response.text);
\`\`\`

### Uso para Processamento de Roteiros
- Usar o modelo `gemini-2.5-flash` para processar roteiros
- Enviar o roteiro completo e solicitar divisão em cenas
- Gerar prompts de imagem para cada cena

### Documentação Oficial
- https://ai.google.dev/gemini-api/docs/quickstart
- https://ai.google.dev/gemini-api/docs/text-generation

### Próximos Passos
1. Instalar o SDK do Gemini
2. Criar uma função para processar roteiros
3. Integrar com o backend do projeto
